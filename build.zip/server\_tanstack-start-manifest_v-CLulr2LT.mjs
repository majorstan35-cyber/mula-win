//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CLulr2LT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/mrhun/Downloads/lucky-spin-kenya-main/lucky-spin-kenya-main/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/api-docs",
			"/auth",
			"/history",
			"/play",
			"/terms",
			"/api/auth/signin",
			"/api/auth/signout",
			"/api/auth/signup",
			"/api/game/history",
			"/api/game/play",
			"/api/game/public-state",
			"/api/public/paystack-webhook",
			"/api/auth/profiles/me",
			"/api/auth/profiles/"
		],
		preloads: ["/assets/index-By-FnOND.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-By-FnOND.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/mrhun/Downloads/lucky-spin-kenya-main/lucky-spin-kenya-main/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CFLvrogS.js"]
	},
	"/admin": {
		filePath: "C:/Users/mrhun/Downloads/lucky-spin-kenya-main/lucky-spin-kenya-main/src/routes/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-DN4u-l02.js", "/assets/auth-middleware-BtMFB2p2.js"]
	},
	"/api-docs": {
		filePath: "C:/Users/mrhun/Downloads/lucky-spin-kenya-main/lucky-spin-kenya-main/src/routes/api-docs.tsx",
		children: void 0,
		preloads: ["/assets/api-docs-Dk4Vvhdx.js"]
	},
	"/auth": {
		filePath: "C:/Users/mrhun/Downloads/lucky-spin-kenya-main/lucky-spin-kenya-main/src/routes/auth.tsx",
		children: void 0,
		preloads: ["/assets/auth-BtNmWaLw.js"]
	},
	"/history": {
		filePath: "C:/Users/mrhun/Downloads/lucky-spin-kenya-main/lucky-spin-kenya-main/src/routes/history.tsx",
		children: void 0,
		preloads: [
			"/assets/history-CD1MJspU.js",
			"/assets/auth-middleware-BtMFB2p2.js",
			"/assets/draw.functions-CxDShSas.js"
		]
	},
	"/play": {
		filePath: "C:/Users/mrhun/Downloads/lucky-spin-kenya-main/lucky-spin-kenya-main/src/routes/play.tsx",
		children: void 0,
		preloads: [
			"/assets/play-yZHkQ_dw.js",
			"/assets/auth-middleware-BtMFB2p2.js",
			"/assets/draw.functions-CxDShSas.js"
		]
	},
	"/terms": {
		filePath: "C:/Users/mrhun/Downloads/lucky-spin-kenya-main/lucky-spin-kenya-main/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-Bwkrhe-H.js"]
	}
} });
//#endregion
export { tsrStartManifest };
