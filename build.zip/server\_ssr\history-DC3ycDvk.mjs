import { a as __toESM } from "../_runtime.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { n as useServerFn } from "./createSsrRpc-BeJ9_ac2.mjs";
import { n as useAuth } from "./auth-context-c4SXRgOr.mjs";
import { t as getMyHistory } from "./draw.functions-BNzUF7Rk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/history-DC3ycDvk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HistoryPage() {
	const { user, loading } = useAuth();
	const navigate = useNavigate();
	const fetchHistory = useServerFn(getMyHistory);
	const [rows, setRows] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (!loading && !user) navigate({ to: "/auth" });
	}, [
		loading,
		user,
		navigate
	]);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		fetchHistory().then((d) => setRows(d)).finally(() => setBusy(false));
	}, [fetchHistory, user]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-md px-5 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "text-sm text-[color:var(--muted-foreground)]",
				children: "← Back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-display text-3xl font-bold",
				children: "Your history"
			}),
			busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-[color:var(--muted-foreground)]",
				children: "Loading…"
			}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-2xl border border-[color:var(--border)] bg-[color:var(--card)]/40 p-6 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-[color:var(--muted-foreground)]",
					children: "No plays yet."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/play",
					className: "mt-3 inline-block text-sm font-semibold text-[color:var(--gold-soft)]",
					children: "Play your first round →"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 space-y-3",
				children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl border border-[color:var(--border)] bg-[color:var(--card)]/50 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[color:var(--muted-foreground)]",
								children: new Date(r.drawn_at ?? r.created_at).toLocaleString()
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-display text-lg font-bold text-[color:var(--gold-soft)]",
								children: [r.matched_count ?? 0, "/12"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-1",
							children: (r.player_numbers ?? []).map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-md border border-[color:var(--border)] px-2 py-0.5 font-mono text-xs",
								children: n
							}, i))
						}),
						r.prize_kes > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 text-sm font-semibold text-[color:var(--gold)]",
							children: ["Won KES ", r.prize_kes.toLocaleString()]
						})
					]
				}, r.id))
			})
		]
	});
}
//#endregion
export { HistoryPage as component };
