import { a as __toESM } from "../_runtime.mjs";
import { t as __exportAll } from "./auth.server-phwZTC7H.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import { t as require_bcrypt } from "../_libs/bcrypt+node-gyp-build.mjs";
import process from "node:process";
//#region node_modules/.nitro/vite/services/ssr/index.js
var import_bcrypt = /* @__PURE__ */ __toESM(require_bcrypt());
var lastCapturedError;
var TTL_MS = 5e3;
function record(error) {
	lastCapturedError = {
		error,
		at: Date.now()
	};
}
if (typeof globalThis.addEventListener === "function") {
	globalThis.addEventListener("error", (event) => record(event.error ?? event));
	globalThis.addEventListener("unhandledrejection", (event) => record(event.reason));
}
function consumeLastCapturedError() {
	if (!lastCapturedError) return void 0;
	if (Date.now() - lastCapturedError.at > TTL_MS) {
		lastCapturedError = void 0;
		return;
	}
	const { error } = lastCapturedError;
	lastCapturedError = void 0;
	return error;
}
function renderErrorPage() {
	return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>This page didn't load</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      body { font: 15px/1.5 system-ui, -apple-system, sans-serif; background: #fafafa; color: #111; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 1.5rem; }
      .card { max-width: 28rem; width: 100%; text-align: center; padding: 2rem; }
      h1 { font-size: 1.25rem; margin: 0 0 0.5rem; }
      p { color: #4b5563; margin: 0 0 1.5rem; }
      .actions { display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap; }
      a, button { padding: 0.5rem 1rem; border-radius: 0.375rem; font: inherit; cursor: pointer; text-decoration: none; border: 1px solid transparent; }
      .primary { background: #111; color: #fff; }
      .secondary { background: #fff; color: #111; border-color: #d1d5db; }
    </style>
  </head>
  <body>
    <div class="card">
      <h1>This page didn't load</h1>
      <p>Something went wrong on our end. You can try refreshing or head back home.</p>
      <div class="actions">
        <button class="primary" onclick="location.reload()">Try again</button>
        <a class="secondary" href="/">Go home</a>
      </div>
    </div>
  </body>
</html>`;
}
var db_server_exports = /* @__PURE__ */ __exportAll({
	ensureDbInitialized: () => ensureDbInitialized,
	supabase: () => supabase
});
var supabase = createClient(process.env.SUPABASE_URL || "https://bimncazhqsoraeztekcc.supabase.co", process.env.SUPABASE_SERVICE_ROLE_KEY || "sb_secret_p1hikiAetKuXcKMSkIaUUg_BQNoJbf3");
var _initPromise = null;
async function runInit() {
	console.log("[db] Initializing schema via Supabase...");
	const { error } = await supabase.from("users").select("id").limit(1);
	if (error && (error.code === "42P01" || /does not exist/i.test(error.message || ""))) {
		console.error("[db] public.users table does not exist.");
		console.error("[db] Please run the migration SQL in Supabase SQL Editor first.");
		console.error("[db] URL: https://bimncazhqsoraeztekcc.supabase.co/project/sql/new");
		throw new Error("Database not initialized. Run migrations first.");
	}
	for (const admin of [{
		email: "superadmin@luckyspin.co.ke",
		password: "SuperPassword123!",
		display_name: "Super Administrator"
	}, {
		email: "admin@luckyspin.co.ke",
		password: "AdminPassword123!",
		display_name: "Admin"
	}]) {
		const { data: existing } = await supabase.from("users").select("id").eq("email", admin.email).maybeSingle();
		if (!existing) {
			console.log(`[db] Seeding admin user: ${admin.email}`);
			const passwordHash = await import_bcrypt.default.hash(admin.password, 10);
			const { data: insertData, error: insertError } = await supabase.from("users").insert({
				email: admin.email,
				password_hash: passwordHash,
				phone: null,
				raw_user_meta_data: { display_name: admin.display_name }
			}).select("id").single();
			if (insertError) {
				console.error(`[db] Failed to seed admin ${admin.email}:`, insertError.message);
				continue;
			}
			const userId = insertData.id;
			const { error: profileError } = await supabase.from("profiles").upsert({
				id: userId,
				phone: null,
				display_name: admin.display_name,
				blocked: false
			});
			if (profileError) console.error(`[db] Failed to create profile for ${admin.email}:`, profileError.message);
			const { error: roleError } = await supabase.from("user_roles").insert({
				user_id: userId,
				role: "admin"
			});
			if (roleError && roleError.code !== "23505") console.error(`[db] Failed to assign role for ${admin.email}:`, roleError.message);
		}
	}
	console.log("[db] Schema initialization complete.");
}
function ensureDbInitialized() {
	if (!_initPromise) _initPromise = runInit().catch((err) => {
		_initPromise = null;
		console.error("[db] Initialization failed:", err.message);
		throw err;
	});
	return _initPromise;
}
ensureDbInitialized().catch(() => {});
var serverEntryPromise;
async function getServerEntry() {
	if (!serverEntryPromise) serverEntryPromise = import("./server-SOkYqiSq.mjs").then((m) => m.default ?? m);
	return serverEntryPromise;
}
async function normalizeCatastrophicSsrResponse(response) {
	if (response.status < 500) return response;
	if (!(response.headers.get("content-type") ?? "").includes("application/json")) return response;
	const body = await response.clone().text();
	if (isH3SwallowedErrorBody(body)) return response;
	console.error(consumeLastCapturedError() ?? /* @__PURE__ */ new Error(`h3 swallowed SSR error: ${body}`));
	return new Response(renderErrorPage(), {
		status: 500,
		headers: { "content-type": "text/html; charset=utf-8" }
	});
}
function isH3SwallowedErrorBody(body) {
	try {
		const payload = JSON.parse(body);
		return payload.unhandled === true && payload.message === "HTTPError";
	} catch {
		return false;
	}
}
var server_default = { async fetch(request, env, ctx) {
	try {
		return await normalizeCatastrophicSsrResponse(await (await getServerEntry()).fetch(request, env, ctx));
	} catch (error) {
		console.error(error);
		return new Response(renderErrorPage(), {
			status: 500,
			headers: { "content-type": "text/html; charset=utf-8" }
		});
	}
} };
//#endregion
export { server_default as default, renderErrorPage as n, db_server_exports as t };
