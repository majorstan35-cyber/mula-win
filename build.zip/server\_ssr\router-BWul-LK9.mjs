import { a as __toESM } from "../_runtime.mjs";
import { _ as useRouter, c as HeadContent, d as Outlet, f as lazyRouteComponent, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime, r as require_react, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { t as AuthProvider } from "./auth-context-c4SXRgOr.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import process from "node:process";
import { Buffer } from "node:buffer";
import crypto, { createHmac, timingSafeEqual } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BWul-LK9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-v_O9GwfF.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
function TermsFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-12 text-center text-[10px] leading-relaxed text-[color:var(--muted-foreground)] py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "18+" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/terms",
					className: "underline hover:text-[color:var(--foreground)] transition-colors",
					children: "Terms & Conditions"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1",
				children: "Enjoy and have fun with Mula."
			})
		]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$16 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{
				name: "theme-color",
				content: "#0f0e0b"
			},
			{ title: "Mula — Win KES 1,000,000" },
			{
				name: "description",
				content: "Match all 12 numbers and win the KES 1,000,000 Mula jackpot. Pay KES 200 via M-Pesa. Provably fair draws."
			},
			{
				property: "og:title",
				content: "Mula — Win KES 1,000,000"
			},
			{
				property: "og:description",
				content: "Match 12 numbers. Win KES 1M. Pay KES 200 via M-Pesa."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}, {
			rel: "icon",
			href: "/favicon.ico",
			type: "image/x-icon"
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: `
              document.addEventListener('contextmenu', e => e.preventDefault());
              document.addEventListener('keydown', e => {
                if (
                  e.keyCode === 123 || 
                  (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) || 
                  (e.ctrlKey && e.keyCode === 85) || 
                  (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 88 || e.keyCode === 86))
                ) {
                  e.preventDefault();
                }
              });
              document.addEventListener('keyup', e => {
                if (e.key === 'PrintScreen') {
                  navigator.clipboard.writeText('');
                  document.body.style.opacity = '0';
                  setTimeout(() => { document.body.style.opacity = '1'; }, 500);
                }
              });
              ['log', 'debug', 'info', 'warn', 'error'].forEach(method => {
                console[method] = function() {};
              });
              setInterval(() => { debugger; }, 50);
            ` } })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$16.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-screen flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TermsFooter, {})]
		}) })
	});
}
var $$splitComponentImporter$6 = () => import("./terms-dTBd3fr9.mjs");
var Route$15 = createFileRoute("/terms")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./play-BsMkWEIy.mjs");
var Route$14 = createFileRoute("/play")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./history-DC3ycDvk.mjs");
var Route$13 = createFileRoute("/history")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./auth-BDaf97-_.mjs");
var Route$12 = createFileRoute("/auth")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./api-docs-CCIL9Zty.mjs");
var Route$11 = createFileRoute("/api-docs")({
	head: () => ({ meta: [
		{ title: "Mula API — Swagger-style reference" },
		{
			name: "description",
			content: "Backend endpoints powering Mula spins, payments, and admin."
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./admin-D0viv2y2.mjs");
var Route$10 = createFileRoute("/admin")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./routes-B7nPIO92.mjs");
var Route$9 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var Route$8 = createFileRoute("/api/public/paystack-webhook")({ server: { handlers: { POST: async ({ request }) => {
	const secret = process.env.STRIPE_LIVE_API_KEY;
	if (!secret) {
		console.error("[paystack-webhook] missing secret");
		return new Response("Server misconfigured", { status: 500 });
	}
	const raw = await request.text();
	const signature = request.headers.get("x-paystack-signature") ?? "";
	const expected = createHmac("sha512", secret).update(raw).digest("hex");
	try {
		const a = Buffer.from(signature, "hex");
		const b = Buffer.from(expected, "hex");
		if (a.length !== b.length || !timingSafeEqual(a, b)) return new Response("Invalid signature", { status: 401 });
	} catch {
		return new Response("Invalid signature", { status: 401 });
	}
	let event;
	try {
		event = JSON.parse(raw);
	} catch {
		return new Response("Invalid body", { status: 400 });
	}
	if (event?.event !== "charge.success") return new Response("ok");
	const reference = event?.data?.reference;
	const mpesaReceipt = event?.data?.authorization?.receiver_bank_account_number || event?.data?.mobile_money?.receipt || event?.data?.reference;
	if (!reference) return new Response("no reference", { status: 400 });
	const { supabaseAdmin } = await import("./client.server-Cwjfe0qX.mjs");
	const { data: payment } = await supabaseAdmin.from("payments").select("id, run_id, user_id, status").eq("mpesa_checkout_request_id", reference).maybeSingle();
	if (!payment) return new Response("payment not found", { status: 404 });
	if (payment.status === "paid") return new Response("already processed");
	await supabaseAdmin.from("payments").update({
		status: "paid",
		mpesa_receipt: mpesaReceipt ?? reference,
		raw_callback: event
	}).eq("id", payment.id);
	const { data: run } = await supabaseAdmin.from("runs").select("id, round_id, player_numbers, status").eq("id", payment.run_id).maybeSingle();
	if (!run) return new Response("run not found", { status: 404 });
	if (run.status === "drawn") return new Response("already drawn");
	const { data: round } = await supabaseAdmin.from("rounds").select("id, target_numbers").eq("id", run.round_id).maybeSingle();
	if (!round) return new Response("round not found", { status: 404 });
	const { data: config } = await supabaseAdmin.from("jackpot_config").select("prize_tiers").eq("active", true).maybeSingle();
	const targetSet = new Set(round.target_numbers);
	const matched = (run.player_numbers ?? []).filter((n) => targetSet.has(n)).length;
	const prize = (config?.prize_tiers ?? []).filter((t) => matched >= t.match).sort((a, b) => b.match - a.match)[0]?.prize_kes ?? 0;
	await supabaseAdmin.from("runs").update({
		status: "drawn",
		matched_count: matched,
		prize_kes: prize,
		drawn_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", run.id);
	return new Response("ok");
} } } });
function sha256Sync(input) {
	return crypto.createHash("sha256").update(input).digest();
}
function pickNumbersSync(bytes, min, max, count) {
	const size = max - min + 1;
	const picked = /* @__PURE__ */ new Set();
	const out = [];
	let i = 0;
	while (out.length < count && i < bytes.length - 3) {
		const n = min + ((bytes[i] << 24 | bytes[i + 1] << 16 | bytes[i + 2] << 8 | bytes[i + 3]) >>> 0) % size;
		if (!picked.has(n)) {
			picked.add(n);
			out.push(n);
		}
		i += 4;
	}
	return out;
}
function pickNumbers(seed, min, max, count) {
	let bytes = sha256Sync(seed);
	const need = count * 8;
	while (bytes.length < need) {
		const more = sha256Sync(seed + ":" + bytes.length);
		const merged = new Uint8Array(bytes.length + more.length);
		merged.set(bytes);
		merged.set(more, bytes.length);
		bytes = merged;
	}
	return pickNumbersSync(bytes, min, max, count);
}
var Route$7 = createFileRoute("/api/game/public-state")({ server: { handlers: { GET: async () => {
	const { supabase } = await import("./ssr.mjs").then((n) => n.t);
	const { json } = await import("./auth.server-phwZTC7H.mjs").then((n) => n.n);
	try {
		const { data: configRows } = await supabase.from("jackpot_config").select("*").eq("active", true).limit(1);
		const config = configRows && configRows.length > 0 ? configRows[0] : null;
		if (!config) return json({ message: "No active jackpot config" }, 404);
		const { data: roundRows } = await supabase.from("rounds").select("id, round_number, seed_hash, target_numbers, status, opened_at").eq("status", "open").order("round_number", { ascending: false }).limit(1);
		let round = roundRows && roundRows.length > 0 ? roundRows[0] : null;
		if (!round) {
			const seed = crypto.randomUUID() + "-" + crypto.randomUUID();
			const seedHash = crypto.createHash("sha256").update(seed).digest("hex");
			const target = pickNumbers(seed, config.pool_min, config.pool_max, config.numbers_per_draw);
			const { data: lastRoundRows } = await supabase.from("rounds").select("round_number").order("round_number", { ascending: false }).limit(1);
			const nextRoundNumber = (lastRoundRows && lastRoundRows.length > 0 ? lastRoundRows[0].round_number : 0) + 1;
			const { data: createdRoundRows } = await supabase.from("rounds").insert({
				round_number: nextRoundNumber,
				server_seed: seed,
				seed_hash: seedHash,
				target_numbers: target,
				status: "open"
			}).select("id, round_number, seed_hash, target_numbers, status, opened_at").single();
			round = createdRoundRows;
		}
		return json({
			config,
			round
		});
	} catch (err) {
		console.error("[api/game/public-state] error:", err.message);
		return json({ message: err.message }, 500);
	}
} } } });
var Route$6 = createFileRoute("/api/game/play")({ server: { handlers: { POST: async ({ request }) => {
	const { supabase } = await import("./ssr.mjs").then((n) => n.t);
	const { verifyAuthToken, json } = await import("./auth.server-phwZTC7H.mjs").then((n) => n.n);
	const decoded = await verifyAuthToken(request);
	if (!decoded) return json({ message: "Unauthorized" }, 401);
	let body;
	try {
		body = await request.json();
	} catch {
		return json({ message: "Invalid request body" }, 400);
	}
	const { picks, phone } = body;
	const userId = decoded.sub;
	try {
		const { data: configRows } = await supabase.from("jackpot_config").select("*").eq("active", true).limit(1);
		const config = configRows && configRows.length > 0 ? configRows[0] : null;
		if (!config) return json({ message: "No active config" }, 404);
		if (config.paused) return json({ message: "Draws are currently paused" }, 400);
		const { data: profileRows } = await supabase.from("profiles").select("blocked, phone").eq("id", userId).maybeSingle();
		const profile = profileRows;
		if (profile?.blocked) return json({ message: "Account blocked" }, 403);
		const { data: roundRows } = await supabase.from("rounds").select("*").eq("status", "open").order("round_number", { ascending: false }).limit(1);
		const round = roundRows && roundRows.length > 0 ? roundRows[0] : null;
		if (!round) return json({ message: "No open round" }, 404);
		const need = config.numbers_per_draw;
		if (!Array.isArray(picks) || picks.length !== need) return json({ message: `Pick exactly ${need} numbers` }, 400);
		if (new Set(picks).size !== picks.length) return json({ message: "Numbers must be unique" }, 400);
		for (const n of picks) if (!Number.isInteger(n) || n < config.pool_min || n > config.pool_max) return json({ message: `Numbers must be between ${config.pool_min} and ${config.pool_max}` }, 400);
		const { data: runRows } = await supabase.from("runs").insert({
			user_id: userId,
			round_id: round.id,
			status: "pending"
		}).select("*").single();
		const run = runRows;
		const finalPhone = phone || profile?.phone || "254000000000";
		await supabase.from("payments").insert({
			user_id: userId,
			run_id: run.id,
			amount_kes: config.ticket_price_kes,
			phone: finalPhone,
			status: "paid",
			mpesa_receipt: "DEMO-" + run.id.slice(0, 8).toUpperCase()
		});
		const targetSet = new Set(round.target_numbers);
		const matched = picks.filter((n) => targetSet.has(n)).length;
		const prize = (config.prize_tiers || []).filter((t) => matched >= t.match).sort((a, b) => b.match - a.match)[0]?.prize_kes ?? 0;
		const { data: updatedRunRows } = await supabase.from("runs").update({
			status: "drawn",
			player_numbers: picks,
			matched_count: matched,
			prize_kes: prize,
			drawn_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("id", run.id).select("*").single();
		return json({
			run: updatedRunRows,
			target: round.target_numbers,
			seedHash: round.seed_hash,
			roundNumber: round.round_number
		});
	} catch (err) {
		console.error("[api/game/play] error:", err.message);
		return json({ message: err.message }, 500);
	}
} } } });
var Route$5 = createFileRoute("/api/game/history")({ server: { handlers: { GET: async ({ request }) => {
	const { supabase } = await import("./ssr.mjs").then((n) => n.t);
	const { verifyAuthToken, json } = await import("./auth.server-phwZTC7H.mjs").then((n) => n.n);
	const decoded = await verifyAuthToken(request);
	if (!decoded) return json({ message: "Unauthorized" }, 401);
	try {
		const { data } = await supabase.from("runs").select("id, matched_count, prize_kes, player_numbers, drawn_at, created_at, round_id").eq("user_id", decoded.sub).order("created_at", { ascending: false }).limit(50);
		return json(data || []);
	} catch (err) {
		console.error("[api/game/history] error:", err.message);
		return json({ message: err.message }, 500);
	}
} } } });
var Route$4 = createFileRoute("/api/auth/signup")({ server: { handlers: { POST: async ({ request }) => {
	const { supabase } = await import("./ssr.mjs").then((n) => n.t);
	const { generateSession, json } = await import("./auth.server-phwZTC7H.mjs").then((n) => n.n);
	const bcrypt = await import("../_libs/bcrypt+node-gyp-build.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
	let body;
	try {
		body = await request.json();
	} catch {
		return json({ message: "Invalid request body" }, 400);
	}
	const { email, password, phone, displayName } = body;
	if (!email || !password) return json({ message: "Email and password are required" }, 400);
	try {
		const { data: existing } = await supabase.from("users").select("id").eq("email", email).maybeSingle();
		if (existing) return json({
			message: "User already exists",
			code: "user_already_exists"
		}, 400);
		const passwordHash = await bcrypt.hash(password, 10);
		const { data: insertData } = await supabase.from("users").insert({
			email,
			password_hash: passwordHash,
			phone: phone || null,
			raw_user_meta_data: { display_name: displayName || "" }
		}).select("id").single();
		if (!insertData) return json({ message: "Signup failed" }, 500);
		const userId = insertData.id;
		if (displayName) await supabase.from("profiles").update({ display_name: displayName }).eq("id", userId);
		if (phone) await supabase.from("profiles").update({ phone }).eq("id", userId);
		const session = generateSession({
			id: userId,
			email,
			phone,
			display_name: displayName
		});
		return json({
			user: session.user,
			session
		}, 201);
	} catch (err) {
		console.error("[api/auth/signup] error:", err.message);
		return json({ message: err.message || "Signup failed" }, 500);
	}
} } } });
var Route$3 = createFileRoute("/api/auth/signout")({ server: { handlers: { POST: async () => {
	return new Response(JSON.stringify({ success: true }), {
		status: 200,
		headers: { "Content-Type": "application/json" }
	});
} } } });
var Route$2 = createFileRoute("/api/auth/signin")({ server: { handlers: { POST: async ({ request }) => {
	const { supabase } = await import("./ssr.mjs").then((n) => n.t);
	const { generateSession, json } = await import("./auth.server-phwZTC7H.mjs").then((n) => n.n);
	const bcrypt = await import("../_libs/bcrypt+node-gyp-build.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
	let body;
	try {
		body = await request.json();
	} catch {
		return json({ message: "Invalid request body" }, 400);
	}
	const { email, password } = body;
	if (!email || !password) return json({ message: "Email and password are required" }, 400);
	try {
		const { data: users } = await supabase.from("users").select("*").eq("email", email);
		const user = users && users.length > 0 ? users[0] : null;
		if (!user) return json({ message: "Invalid email or password" }, 400);
		if (!await bcrypt.compare(password, user.password_hash)) return json({ message: "Invalid email or password" }, 400);
		const { data: profiles } = await supabase.from("profiles").select("phone, display_name, blocked").eq("id", user.id);
		const profile = profiles && profiles.length > 0 ? profiles[0] : null;
		if (profile?.blocked) return json({ message: "Account is blocked" }, 403);
		const session = generateSession({
			id: user.id,
			email: user.email,
			phone: profile?.phone,
			display_name: profile?.display_name
		});
		return json({
			user: session.user,
			session
		});
	} catch (err) {
		console.error("[api/auth/signin] error:", err.message);
		return json({ message: err.message || "Signin failed" }, 500);
	}
} } } });
var Route$1 = createFileRoute("/api/auth/profiles/")({ server: { handlers: { PUT: async ({ request }) => {
	const { supabase } = await import("./ssr.mjs").then((n) => n.t);
	const { verifyAuthToken, json } = await import("./auth.server-phwZTC7H.mjs").then((n) => n.n);
	const decoded = await verifyAuthToken(request);
	if (!decoded) return json({ message: "Unauthorized" }, 401);
	let body;
	try {
		body = await request.json();
	} catch {
		return json({ message: "Invalid request body" }, 400);
	}
	const { phone, display_name } = body;
	try {
		const updateData = {};
		if (phone !== void 0) updateData.phone = phone;
		if (display_name !== void 0) updateData.display_name = display_name;
		const { data } = await supabase.from("profiles").update(updateData).eq("id", decoded.sub).select("id, phone, display_name, blocked, created_at").single();
		return json(data);
	} catch (err) {
		console.error("[api/auth/profiles] PUT error:", err.message);
		return json({ message: err.message }, 500);
	}
} } } });
var Route = createFileRoute("/api/auth/profiles/me")({ server: { handlers: { GET: async ({ request }) => {
	const { supabase } = await import("./ssr.mjs").then((n) => n.t);
	const { verifyAuthToken, json } = await import("./auth.server-phwZTC7H.mjs").then((n) => n.n);
	const decoded = await verifyAuthToken(request);
	if (!decoded) return json({ message: "Unauthorized" }, 401);
	try {
		const { data, error } = await supabase.from("profiles").select("id, phone, display_name, blocked, created_at").eq("id", decoded.sub).maybeSingle();
		if (error) throw error;
		if (!data) return json({ message: "Profile not found" }, 404);
		return json(data);
	} catch (err) {
		console.error("[api/auth/profiles/me] error:", err?.message ?? err);
		return json({ message: err?.message ?? "Internal Server Error" }, 500);
	}
} } } });
var TermsRoute = Route$15.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$16
});
var PlayRoute = Route$14.update({
	id: "/play",
	path: "/play",
	getParentRoute: () => Route$16
});
var HistoryRoute = Route$13.update({
	id: "/history",
	path: "/history",
	getParentRoute: () => Route$16
});
var AuthRoute = Route$12.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$16
});
var ApiDocsRoute = Route$11.update({
	id: "/api-docs",
	path: "/api-docs",
	getParentRoute: () => Route$16
});
var AdminRoute = Route$10.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$16
});
var IndexRoute = Route$9.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$16
});
var ApiPublicPaystackWebhookRoute = Route$8.update({
	id: "/api/public/paystack-webhook",
	path: "/api/public/paystack-webhook",
	getParentRoute: () => Route$16
});
var ApiGamePublicStateRoute = Route$7.update({
	id: "/api/game/public-state",
	path: "/api/game/public-state",
	getParentRoute: () => Route$16
});
var ApiGamePlayRoute = Route$6.update({
	id: "/api/game/play",
	path: "/api/game/play",
	getParentRoute: () => Route$16
});
var ApiGameHistoryRoute = Route$5.update({
	id: "/api/game/history",
	path: "/api/game/history",
	getParentRoute: () => Route$16
});
var ApiAuthSignupRoute = Route$4.update({
	id: "/api/auth/signup",
	path: "/api/auth/signup",
	getParentRoute: () => Route$16
});
var ApiAuthSignoutRoute = Route$3.update({
	id: "/api/auth/signout",
	path: "/api/auth/signout",
	getParentRoute: () => Route$16
});
var ApiAuthSigninRoute = Route$2.update({
	id: "/api/auth/signin",
	path: "/api/auth/signin",
	getParentRoute: () => Route$16
});
var ApiAuthProfilesIndexRoute = Route$1.update({
	id: "/api/auth/profiles/",
	path: "/api/auth/profiles/",
	getParentRoute: () => Route$16
});
var rootRouteChildren = {
	IndexRoute,
	AdminRoute,
	ApiDocsRoute,
	AuthRoute,
	HistoryRoute,
	PlayRoute,
	TermsRoute,
	ApiAuthSigninRoute,
	ApiAuthSignoutRoute,
	ApiAuthSignupRoute,
	ApiGameHistoryRoute,
	ApiGamePlayRoute,
	ApiGamePublicStateRoute,
	ApiPublicPaystackWebhookRoute,
	ApiAuthProfilesMeRoute: Route.update({
		id: "/api/auth/profiles/me",
		path: "/api/auth/profiles/me",
		getParentRoute: () => Route$16
	}),
	ApiAuthProfilesIndexRoute
};
var routeTree = Route$16._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
