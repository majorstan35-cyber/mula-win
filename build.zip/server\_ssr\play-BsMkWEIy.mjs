import { a as __toESM } from "../_runtime.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { n as useServerFn, t as createSsrRpc } from "./createSsrRpc-BeJ9_ac2.mjs";
import { t as supabase } from "./client-BM5UVnrl.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CvvfbxTP.mjs";
import { n as useAuth } from "./auth-context-c4SXRgOr.mjs";
import { n as getPublicState } from "./draw.functions-BNzUF7Rk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/play-BsMkWEIy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var initiateMpesaCharge = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((data) => data).handler(createSsrRpc("2c5a1c3f656b2ce185d8efc1cf1ddc58e316d37ce9230bef0f7259644f6ea4e9"));
var getRunStatus = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).validator((data) => data).handler(createSsrRpc("b26d90fa23774e657989ba272e7498a807e3286d09b2230b9dda540c8124536f"));
var CITIES = [
	"Nairobi",
	"Mombasa",
	"Kisumu",
	"Nakuru",
	"Eldoret",
	"Thika",
	"Nyeri",
	"Kakamega",
	"Embu",
	"Meru",
	"Machakos",
	"Kitale",
	"Kericho",
	"Malindi",
	"Kilifi",
	"Naivasha",
	"Kisii",
	"Bungoma",
	"Garissa",
	"Isiolo",
	"Voi",
	"Lamu",
	"Diani",
	"Karatina",
	"Ruiru",
	"Kiambu",
	"Athi River",
	"Nanyuki",
	"Kajiado",
	"Migori",
	"Homa Bay",
	"Busia"
];
function generateOrganicMessage(matched) {
	const pool = matched >= 10 ? [
		"Almost!",
		"Oh my god so close",
		"Missed by 2 numbers!",
		"Ayaya, missed by one",
		"No way, matched 10",
		"My heart stopped",
		"I remained with only two",
		"Jackpot loading for sure"
	] : matched >= 7 ? [
		"Getting closer",
		"Feeling lucky today",
		"Let's go again",
		"Almost got half",
		"Chapaa inakuja soon",
		"Not bad, let's keep pushing",
		"Bahati iko karibu",
		"Next spin is mine"
	] : [
		"Missed by a whisker",
		"We try again",
		"Bahati mbaya",
		"Ah, just missed it",
		"Nakuja tena",
		"Trust the process",
		"One more spin",
		"Warm up spin done"
	];
	const base = pool[Math.floor(Math.random() * pool.length)];
	const emojis = [
		"",
		"!",
		"!!",
		"...",
		" 😭",
		" 🔥",
		" 🍀",
		" 💸",
		" 😤",
		" 🚀",
		" 🤞",
		" 💔",
		" 😱"
	];
	const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
	const swahiliStart = [
		"",
		"",
		"",
		"Manze, ",
		"Wueh, ",
		"Ala! ",
		"Enyewe, ",
		"Aish, "
	];
	return `${swahiliStart[Math.floor(Math.random() * swahiliStart.length)]}${base}${randomEmoji}`;
}
function randomFeedItem(id, secondsAgo = 0) {
	const rand = Math.random();
	let matched = 5;
	if (rand < .25) matched = 4;
	else if (rand < .5) matched = 5;
	else if (rand < .7) matched = 6;
	else if (rand < .85) matched = 7;
	else if (rand < .93) matched = 8;
	else if (rand < .97) matched = 9;
	else if (rand < .995) matched = 10;
	else matched = 11;
	return {
		id,
		tag: `Player #${Math.floor(1e3 + Math.random() * 8999)}`,
		city: CITIES[Math.floor(Math.random() * CITIES.length)],
		matched,
		secondsAgo,
		msg: generateOrganicMessage(matched)
	};
}
function formatAgo(s) {
	if (s < 60) return `${s}s ago`;
	const m = Math.floor(s / 60);
	if (m < 60) return `${m}m ago`;
	return `${Math.floor(m / 60)}h ago`;
}
function PlayPage() {
	const { user, loading } = useAuth();
	const navigate = useNavigate();
	const startCharge = useServerFn(initiateMpesaCharge);
	const pollRun = useServerFn(getRunStatus);
	const runState = useServerFn(getPublicState);
	const [poolMin, setPoolMin] = (0, import_react.useState)(1);
	const [poolMax, setPoolMax] = (0, import_react.useState)(40);
	const [need, setNeed] = (0, import_react.useState)(12);
	const [picks, setPicks] = (0, import_react.useState)([
		10,
		20,
		27,
		1,
		36,
		5,
		13,
		39,
		38,
		12,
		16,
		25
	]);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [reveal, setReveal] = (0, import_react.useState)([]);
	const [result, setResult] = (0, import_react.useState)(null);
	const [feed, setFeed] = (0, import_react.useState)(() => Array.from({ length: 8 }, (_, i) => randomFeedItem(i, i * 15 + Math.floor(Math.random() * 20))));
	const [online, setOnline] = (0, import_react.useState)(() => Math.floor(1100 + Math.random() * 400));
	const trendRef = (0, import_react.useRef)(1);
	(0, import_react.useEffect)(() => {
		let nextId = 1e3;
		const tick = () => {
			setFeed((prev) => {
				const aged = prev.map((f) => ({
					...f,
					secondsAgo: f.secondsAgo + 4
				}));
				return [randomFeedItem(nextId++, 0), ...aged].slice(0, 8);
			});
			setOnline((n) => {
				if (Math.random() < .05) trendRef.current *= -1;
				if (n <= 920) trendRef.current = 1;
				if (n >= 2280) trendRef.current = -1;
				const newVal = n + (Math.floor(Math.random() * 15) + 5) * trendRef.current;
				return Math.max(900, Math.min(2300, newVal));
			});
		};
		const id = setInterval(tick, 3500);
		return () => clearInterval(id);
	}, []);
	const [err, setErr] = (0, import_react.useState)(null);
	const [payOpen, setPayOpen] = (0, import_react.useState)(false);
	const [payStep, setPayStep] = (0, import_react.useState)(null);
	const [phone, setPhone] = (0, import_react.useState)("");
	const [phoneLoaded, setPhoneLoaded] = (0, import_react.useState)(false);
	const [stkMsg, setStkMsg] = (0, import_react.useState)("");
	const [runId, setRunId] = (0, import_react.useState)(null);
	const pollTimer = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		supabase.from("profiles").select("phone").eq("id", user.id).maybeSingle().then(({ data }) => {
			if (data?.phone && !phoneLoaded) {
				setPhone(data.phone);
				setPhoneLoaded(true);
			}
		}).catch(() => {});
	}, [user]);
	(0, import_react.useEffect)(() => {
		if (!loading && !user) navigate({ to: "/auth" });
	}, [
		loading,
		user,
		navigate
	]);
	(0, import_react.useEffect)(() => {
		runState().then((s) => {
			setPoolMin(s.config.pool_min);
			setPoolMax(s.config.pool_max);
			setNeed(s.config.numbers_per_draw);
		}).catch(() => {});
	}, [runState]);
	(0, import_react.useEffect)(() => () => {
		if (pollTimer.current) clearInterval(pollTimer.current);
	}, []);
	(0, import_react.useMemo)(() => {
		const arr = [];
		for (let i = poolMin; i <= poolMax; i++) arr.push(i);
		let seed = poolMin * 1e3 + poolMax;
		const rand = () => {
			seed = (seed * 9301 + 49297) % 233280;
			return seed / 233280;
		};
		for (let i = arr.length - 1; i > 0; i--) {
			const j = Math.floor(rand() * (i + 1));
			[arr[i], arr[j]] = [arr[j], arr[i]];
		}
		return arr;
	}, [poolMin, poolMax]);
	(0, import_react.useMemo)(() => new Set(picks), [picks]);
	(0, import_react.useMemo)(() => new Set(reveal), [reveal]);
	const ready = picks.length === need;
	function resetForNextSpin() {
		setPicks([]);
		setReveal([]);
		setResult(null);
		setErr(null);
		setRunId(null);
		setStkMsg("");
		if (pollTimer.current) clearInterval(pollTimer.current);
	}
	function openPay() {
		if (!ready) {
			setErr(`Pick ${need - picks.length} more number${need - picks.length === 1 ? "" : "s"}`);
			return;
		}
		setErr(null);
		setPayStep("phone");
		setPayOpen(true);
	}
	async function submitPhone() {
		let normalized = phone.replace(/\D/g, "");
		if (normalized.startsWith("0")) normalized = "254" + normalized.slice(1);
		else if (normalized.startsWith("7") || normalized.startsWith("1")) normalized = "254" + normalized;
		else if (normalized.startsWith("254")) {} else {
			setErr("Enter a valid Kenyan M-Pesa number (e.g. 0712 345 678)");
			return;
		}
		if (normalized.length !== 12) {
			setErr("Phone number must be 12 digits (e.g. 0712 345 678)");
			return;
		}
		setErr(null);
		setStkMsg("");
		setRunning(true);
		try {
			const res = await startCharge({ data: {
				picks,
				phone
			} });
			setRunId(res.runId);
			setStkMsg(res.displayText);
			setPayStep("stk");
			startPolling(res.runId);
		} catch (e) {
			setErr(e.message ?? "Could not start payment");
			setRunning(false);
		}
	}
	function startPolling(id) {
		let elapsed = 0;
		if (pollTimer.current) clearInterval(pollTimer.current);
		pollTimer.current = setInterval(async () => {
			elapsed += 3;
			try {
				const s = await pollRun({ data: { runId: id } });
				if (s.runStatus === "drawn" && s.run && s.target && s.seedHash && s.roundNumber !== null) {
					if (pollTimer.current) clearInterval(pollTimer.current);
					setPayOpen(false);
					setPayStep(null);
					const alignedTarget = new Array(need).fill(void 0);
					const nonMatched = [];
					for (const num of s.target) {
						const idx = picks.indexOf(num);
						if (idx !== -1) alignedTarget[idx] = num;
						else nonMatched.push(num);
					}
					for (let i = 0; i < alignedTarget.length; i++) if (alignedTarget[i] === void 0) alignedTarget[i] = nonMatched.shift();
					await animateReveal({
						run: {
							id: s.run.id,
							player_numbers: s.run.player_numbers,
							matched_count: s.run.matched_count ?? 0,
							prize_kes: s.run.prize_kes ?? 0
						},
						target: alignedTarget,
						seedHash: s.seedHash,
						roundNumber: s.roundNumber
					});
				} else if (s.runStatus === "failed") {
					if (pollTimer.current) clearInterval(pollTimer.current);
					setErr("Payment failed or was cancelled");
					setRunning(false);
					setPayStep("phone");
				} else if (elapsed > 180) {
					if (pollTimer.current) clearInterval(pollTimer.current);
					setErr("Timed out waiting for M-Pesa confirmation");
					setRunning(false);
					setPayStep("phone");
				}
			} catch (e) {}
		}, 3e3);
	}
	async function animateReveal(r) {
		setReveal([]);
		for (let i = 0; i < r.target.length; i++) {
			await new Promise((res) => setTimeout(res, 320));
			setReveal((prev) => [...prev, r.target[i]]);
		}
		await new Promise((res) => setTimeout(res, 400));
		setResult(r);
		setRunning(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-md px-5 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "text-sm text-[color:var(--muted-foreground)]",
					children: "← Back"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/history",
					className: "text-sm text-[color:var(--gold-soft)]",
					children: "History"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 font-display text-3xl font-bold",
				children: "SPIN & WIN"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-[color:var(--muted-foreground)]",
				children: [
					"Match all ",
					need,
					" to win KES 1,000,000."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 animate-slide-up",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between mb-3 px-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-[color:var(--gold-soft)]",
						children: "Your Lucky Numbers"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] text-[color:var(--muted-foreground)]",
						children: "Locked in"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-2xl border border-[color:var(--gold)]/30 bg-[color:var(--card)] p-4 shadow-gold-soft",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[color:var(--gold)]/5 to-transparent opacity-50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative z-10 grid grid-cols-6 gap-2.5",
						children: picks.map((n, i) => {
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `flex aspect-square items-center justify-center rounded-xl font-display text-lg font-bold transition-all duration-300 ${result && result.target.includes(n) ? "border-2 border-[color:var(--gold)] bg-gold-gradient text-[oklch(0.14_0.01_60)] shadow-gold scale-105" : result ? "border border-[color:var(--border)] bg-[color:var(--card)]/40 text-[color:var(--muted-foreground)] opacity-50" : "border border-[color:var(--gold)]/50 bg-[color:var(--background)] text-[color:var(--gold-soft)] shadow-inner"}`,
								children: n
							}, i);
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between mb-3 px-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-[color:var(--muted-foreground)]",
						children: result ? "Draw Result" : running ? "Spinning…" : "Spin Result"
					}), running && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5 text-[10px] text-[color:var(--gold)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 animate-ping rounded-full bg-[color:var(--gold)]" }), "Drawing"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `relative overflow-hidden rounded-2xl border p-4 transition-all duration-700 ${running ? "animate-casino-border border-[color:var(--gold)]/60 bg-[color:var(--card)]" : result ? "border-[color:var(--gold)]/40 bg-[color:var(--card)]/80" : "border-[color:var(--border)]/40 bg-[color:var(--card)]/50"}`,
					children: [
						running && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-y-0 w-20 pointer-events-none z-20 animate-casino-scan",
							style: { background: "linear-gradient(90deg, transparent 0%, oklch(0.85 0.18 85 / 30%) 50%, transparent 100%)" }
						}),
						(running || result) && [
							"top-2 left-2",
							"top-2 right-2",
							"bottom-2 left-2",
							"bottom-2 right-2"
						].map((pos, ci) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute h-1.5 w-1.5 rounded-full bg-[color:var(--gold)] animate-light-flicker",
							style: {
								animationDelay: `${ci * 200}ms`,
								top: pos.includes("top") ? "8px" : void 0,
								bottom: pos.includes("bottom") ? "8px" : void 0,
								left: pos.includes("left") ? "8px" : void 0,
								right: pos.includes("right") ? "8px" : void 0
							}
						}, ci)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative z-10 grid grid-cols-6 gap-2.5",
							children: Array.from({ length: need }).map((_, i) => {
								const drawnNum = reveal[i];
								const isMatch = drawnNum !== void 0 && picks.includes(drawnNum);
								if (!(drawnNum !== void 0)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex aspect-square items-center justify-center rounded-xl",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: running ? "animate-casino-dot h-3.5 w-3.5 rounded-full" : "h-3.5 w-3.5 rounded-full bg-[color:var(--border)]/50 animate-pulse",
										style: {
											animationDelay: `${i * 100}ms`,
											background: running ? `radial-gradient(circle, oklch(0.88 0.2 85) 0%, oklch(0.65 0.15 75) 100%)` : void 0
										}
									})
								}, i);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `flex aspect-square items-center justify-center rounded-xl font-display text-lg font-bold animate-number-flip transition-all duration-300 ${isMatch ? "border-2 border-[color:var(--gold)] bg-gold-gradient text-[oklch(0.14_0.01_60)] shadow-gold scale-105 animate-light-flicker" : "border border-[color:var(--border)]/60 bg-[color:var(--card)] text-[color:var(--foreground)]/60"}`,
									children: drawnNum
								}, i);
							})
						}),
						!result && !running && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-col items-center justify-center space-y-1 py-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] uppercase tracking-widest text-[color:var(--gold-soft)]/70 animate-pulse",
								children: "Ready for Spin"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px] text-[color:var(--muted-foreground)]/50 tracking-wide",
								children: "Numbers will appear here after your spin"
							})]
						})
					]
				})]
			}),
			result && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-2xl border border-[color:var(--gold)]/30 bg-[color:var(--card)]/60 p-5 text-center animate-slide-up",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs uppercase tracking-widest text-[color:var(--muted-foreground)]",
						children: ["Round #", result.roundNumber]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 font-display text-4xl font-black text-shimmer",
						children: [
							result.run.matched_count,
							"/",
							need,
							" matched"
						]
					}),
					result.run.prize_kes > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 font-display text-2xl font-bold text-[color:var(--gold)]",
						children: ["You won KES ", result.run.prize_kes.toLocaleString()]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 text-sm text-[color:var(--muted-foreground)]",
						children: "No prize this spin. Try again."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 break-all font-mono text-[10px] text-[color:var(--muted-foreground)]",
						children: [
							"Commit: ",
							result.seedHash.slice(0, 24),
							"…"
						]
					})
				]
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 rounded-lg border border-[color:var(--destructive)]/40 bg-[color:var(--destructive)]/10 px-3 py-2 text-xs text-[color:var(--destructive)]",
				children: err
			}),
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: resetForNextSpin,
				className: "bg-gold-gradient shadow-gold mt-6 w-full rounded-2xl py-5 font-display text-2xl font-black text-[oklch(0.12_0.01_60)]",
				children: "Play again"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: openPay,
				disabled: running || !ready,
				className: `mt-6 w-full rounded-2xl py-5 font-display text-2xl font-black transition ${ready && !running ? "animate-gold-pulse bg-gold-gradient shadow-gold text-[oklch(0.12_0.01_60)]" : "bg-[color:var(--card)] text-[color:var(--muted-foreground)] border border-[color:var(--border)]"}`,
				children: running ? "Drawing…" : "SPIN & WIN — KES 200"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-center text-xs text-[color:var(--muted-foreground)]",
				children: "Pay KES 200 via M-Pesa"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs uppercase tracking-[0.24em] text-[color:var(--muted-foreground)]",
						children: "Live spins"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5 text-[10px] text-[color:var(--muted-foreground)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" }),
							online.toLocaleString(),
							" online"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: feed.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: `flex items-center justify-between rounded-xl border border-[color:var(--border)] bg-[color:var(--card)]/50 px-3 py-2.5 text-sm transition-all ${i === 0 ? "animate-slide-up border-[color:var(--gold)]/40" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-semibold",
							children: f.tag
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-[color:var(--muted-foreground)]",
							children: [
								f.city,
								" · ",
								formatAgo(f.secondsAgo),
								" · ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "italic",
									children: [
										"\"",
										f.msg,
										"\""
									]
								})
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-display text-xl font-bold text-[color:var(--gold)]",
								children: [f.matched, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-[color:var(--muted-foreground)]",
									children: ["/", need]
								})]
							})
						})]
					}, f.id))
				})]
			}),
			payOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-t-3xl border border-[color:var(--border)] bg-[color:var(--card)] p-6 shadow-gold sm:rounded-3xl animate-slide-up",
					children: [payStep === "phone" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl font-bold",
								children: "Pay KES 200 via M-Pesa"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									setPayOpen(false);
									setRunning(false);
								},
								disabled: running,
								className: "text-sm text-[color:var(--muted-foreground)] disabled:opacity-40",
								children: "Cancel"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-[color:var(--muted-foreground)]",
							children: "Enter the M-Pesa number to receive the STK prompt."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-5 block text-xs uppercase tracking-widest text-[color:var(--muted-foreground)]",
							children: "M-Pesa phone number"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute left-4 top-1/2 -translate-y-1/2 font-display text-lg text-[color:var(--muted-foreground)] select-none",
								children: "🇰🇪"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "tel",
								inputMode: "tel",
								autoFocus: true,
								placeholder: "0712 345 678",
								value: phone,
								onChange: (e) => setPhone(e.target.value),
								onKeyDown: (e) => {
									if (e.key === "Enter" && !running) submitPhone();
								},
								disabled: running,
								className: "w-full rounded-xl border border-[color:var(--border)] bg-[color:var(--background)]/40 pl-12 pr-4 py-3 font-display text-lg tracking-wide outline-none focus:border-[color:var(--gold)] disabled:opacity-60"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[10px] text-[color:var(--muted-foreground)]",
							children: "Formats accepted: 07XX XXX XXX, 01XX XXX XXX, or +254XXXXXXXXX"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: submitPhone,
							disabled: running || phone.replace(/\D/g, "").length < 9,
							className: "mt-5 w-full rounded-2xl bg-gold-gradient py-4 font-display text-xl font-black text-[oklch(0.12_0.01_60)] shadow-gold disabled:opacity-50 transition active:scale-95",
							children: running ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center justify-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-4 w-4 rounded-full border-2 border-current border-t-transparent animate-spin" }), "Sending STK push…"]
							}) : "📱 Send M-Pesa Prompt"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-center text-[10px] text-[color:var(--muted-foreground)]",
							children: "Powered by Paystack · KES 200 non-refundable"
						})
					] }), payStep === "stk" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-6 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-14 w-14 animate-spin rounded-full border-2 border-[color:var(--gold)] border-t-transparent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 font-display text-xl font-bold",
								children: "Check your phone 📱"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 px-2 text-sm text-[color:var(--muted-foreground)]",
								children: stkMsg || "Enter your M-Pesa PIN to confirm KES 200."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs font-semibold text-[color:var(--gold)]",
								children: ["Sent to: ", phone]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-[10px] text-[color:var(--muted-foreground)]",
								children: "Waiting for M-Pesa confirmation… spinning automatically once paid."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									if (pollTimer.current) clearInterval(pollTimer.current);
									setPayStep("phone");
									setRunning(false);
									setErr(null);
								},
								className: "mt-5 text-xs text-[color:var(--muted-foreground)] underline",
								children: "Didn't receive it? Try again"
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { PlayPage as component };
