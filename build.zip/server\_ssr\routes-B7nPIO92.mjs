import { a as __toESM } from "../_runtime.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { n as useAuth } from "./auth-context-c4SXRgOr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B7nPIO92.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TARGET_NUMBERS = [
	10,
	20,
	27,
	1,
	36,
	5,
	13,
	39,
	38,
	12,
	16,
	25
];
function useCountdown(target) {
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setNow(/* @__PURE__ */ new Date());
		const id = setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		return () => clearInterval(id);
	}, []);
	if (!now) return {
		h: 0,
		m: 0,
		s: 0,
		ready: false
	};
	const diff = Math.max(0, target.getTime() - now.getTime());
	return {
		h: Math.floor(diff / 36e5),
		m: Math.floor(diff % 36e5 / 6e4),
		s: Math.floor(diff % 6e4 / 1e3),
		ready: true
	};
}
function maskPhone(p) {
	return p.replace(/(\d{4})\d{4}(\d{2})/, "$1****$2");
}
var SOCIAL_PROOF = [
	{
		phone: "0712345678",
		matched: 9,
		city: "Nairobi",
		ago: "12s ago"
	},
	{
		phone: "0733112244",
		matched: 7,
		city: "Mombasa",
		ago: "34s ago"
	},
	{
		phone: "0798000111",
		matched: 10,
		city: "Kisumu",
		ago: "1m ago"
	},
	{
		phone: "0721556677",
		matched: 8,
		city: "Nakuru",
		ago: "2m ago"
	},
	{
		phone: "0740998877",
		matched: 11,
		city: "Eldoret",
		ago: "3m ago"
	},
	{
		phone: "0715334422",
		matched: 6,
		city: "Thika",
		ago: "4m ago"
	}
];
function Landing() {
	const { user, signOut } = useAuth();
	const jackpot = 1e6;
	const { h, m, s, ready } = useCountdown((0, import_react.useMemo)(() => {
		const t = /* @__PURE__ */ new Date();
		t.setHours(21, 0, 0, 0);
		if (t.getTime() < Date.now()) t.setDate(t.getDate() + 1);
		return t;
	}, []));
	const [slide, setSlide] = (0, import_react.useState)(0);
	const [onlineCount, setOnlineCount] = (0, import_react.useState)(() => Math.floor(1100 + Math.random() * 400));
	const trendRef = (0, import_react.useRef)(1);
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => {
			setSlide((v) => (v + 1) % SOCIAL_PROOF.length);
			setOnlineCount((n) => {
				if (Math.random() < .05) trendRef.current *= -1;
				if (n <= 920) trendRef.current = 1;
				if (n >= 2280) trendRef.current = -1;
				const newVal = n + (Math.floor(Math.random() * 15) + 5) * trendRef.current;
				return Math.max(900, Math.min(2300, newVal));
			});
		}, 3200);
		return () => clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative min-h-screen overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute inset-x-0 top-0 h-[520px] opacity-60",
			style: { background: "radial-gradient(ellipse at 50% -10%, oklch(0.82 0.16 85 / 0.28), transparent 60%)" }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex min-h-screen max-w-md flex-col px-5 pb-24 pt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-gold-gradient flex h-8 w-8 items-center justify-center rounded-full font-display text-lg font-black text-[oklch(0.14_0.01_60)] shadow-gold-soft",
							children: "M"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl font-bold tracking-tight",
							children: "Mula"
						})]
					}), user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/history",
							className: "rounded-full border border-[color:var(--border)] px-3 py-1.5 text-xs text-[color:var(--muted-foreground)] hover:text-[color:var(--foreground)]",
							children: "History"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: signOut,
							className: "rounded-full border border-[color:var(--border)] px-3 py-1.5 text-xs text-[color:var(--muted-foreground)] hover:text-[color:var(--foreground)]",
							children: "Sign out"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/auth",
						className: "rounded-full border border-[color:var(--border)] px-4 py-1.5 text-xs font-medium text-[color:var(--muted-foreground)] transition hover:text-[color:var(--foreground)]",
						children: "Sign in"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-10 text-center animate-slide-up",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.24em] text-[color:var(--muted-foreground)] animate-pulse",
						children: "Grand Award"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-display text-6xl font-black leading-none text-shimmer sm:text-7xl",
							children: ["KES ", jackpot.toLocaleString()]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-[color:var(--muted-foreground)]",
							children: "Match all 12 numbers. One winner takes it all."
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-10 animate-slide-up",
					style: { animationDelay: "80ms" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-center text-xs font-medium uppercase tracking-[0.24em] text-[color:var(--muted-foreground)]",
						children: "The 12 Numbers to Match"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-6 gap-2",
						children: TARGET_NUMBERS.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "animate-number-flip aspect-square",
							style: { animationDelay: `${i * 60}ms` },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative flex h-full w-full items-center justify-center rounded-xl border border-[color:var(--gold)]/30 bg-gradient-to-br from-[oklch(0.22_0.025_75)] to-[oklch(0.14_0.01_60)] font-display text-xl font-bold text-[color:var(--gold-soft)] shadow-gold-soft",
								children: n
							})
						}, n))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-10 animate-slide-up",
					style: { animationDelay: "160ms" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: user ? "/play" : "/auth",
						className: "animate-gold-pulse bg-gold-gradient shadow-gold block w-full rounded-2xl py-5 text-center font-display text-2xl font-black tracking-tight text-[oklch(0.12_0.01_60)] transition active:scale-[0.98]",
						children: "Tap to Play"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center text-xs text-[color:var(--muted-foreground)]",
						children: "You'll receive an M-Pesa prompt on your phone."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "mt-8 animate-slide-up",
					style: { animationDelay: "240ms" },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden rounded-xl border border-[color:var(--gold)]/40 bg-[color:var(--card)]/60 py-4 text-center shadow-[0_0_15px_rgba(var(--gold-rgb, 180,140,60),0.15)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 z-0 animate-casino-scan bg-gradient-to-r from-transparent via-[color:var(--gold)]/20 to-transparent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "relative z-10 font-display text-sm font-bold tracking-widest text-[color:var(--gold-soft)] animate-light-flicker",
							children: "WIN AND RECEIVE INSTANT PAYMENT"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8 animate-slide-up",
					style: { animationDelay: "320ms" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium uppercase tracking-[0.24em] text-[color:var(--muted-foreground)]",
								children: "Live Activity"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5 text-[10px] text-[color:var(--muted-foreground)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" }),
									onlineCount.toLocaleString(),
									" playing now"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative h-20 overflow-hidden rounded-2xl border border-[color:var(--border)] bg-[color:var(--card)]/50 backdrop-blur",
							children: SOCIAL_PROOF.map((item, i) => {
								const active = i === slide;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute inset-0 flex items-center justify-between px-4 transition-all duration-500",
									style: {
										opacity: active ? 1 : 0,
										transform: `translateY(${active ? 0 : 8}px)`
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-semibold text-[color:var(--foreground)]",
										children: maskPhone(item.phone)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-[color:var(--muted-foreground)]",
										children: [
											item.city,
											" · ",
											item.ago
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-right",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-display text-2xl font-bold text-[color:var(--gold)]",
											children: [item.matched, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm text-[color:var(--muted-foreground)]",
												children: "/12"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]",
											children: "matched"
										})]
									})]
								}, i);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex justify-center gap-1.5",
							children: SOCIAL_PROOF.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "h-1 rounded-full bg-[color:var(--muted-foreground)]/30 transition-all",
								style: {
									width: i === slide ? 18 : 6,
									background: i === slide ? "var(--gold)" : void 0
								}
							}, i))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-10 animate-slide-up",
					style: { animationDelay: "400ms" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-center text-xs font-medium uppercase tracking-[0.24em] text-[color:var(--muted-foreground)]",
						children: "How it works"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "space-y-2",
						children: [
							"Click \"Tap to Play\"",
							"Confirm the M-Pesa prompt on your phone",
							"Watch your 12 numbers reveal live",
							"Match all 12 — win KES 1,000,000"
						].map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 rounded-xl border border-[color:var(--border)] bg-[color:var(--card)]/40 px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex h-7 w-7 flex-none items-center justify-center rounded-full border border-[color:var(--gold)]/40 font-display text-sm font-bold text-[color:var(--gold)]",
								children: i + 1
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-[color:var(--foreground)]/90",
								children: step
							})]
						}, i))
					})]
				})
			]
		})]
	});
}
var SplitComponent = Landing;
//#endregion
export { SplitComponent as component };
