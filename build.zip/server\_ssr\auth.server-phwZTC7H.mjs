import { r as __exportAll$1 } from "../_runtime.mjs";
import { createRequire } from "node:module";
import process from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.server-phwZTC7H.js
var auth_server_phwZTC7H_exports = /* @__PURE__ */ __exportAll$1({
	generateSession: () => generateSession,
	json: () => json,
	t: () => __exportAll,
	verifyAuthToken: () => verifyAuthToken
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var __require = /* @__PURE__ */ createRequire(import.meta.url || "file:///");
var JWT_SECRET = process.env.JWT_SECRET || "super_secret_lucky_spin_jwt_key";
function generateSession(user) {
	return {
		access_token: __require("jsonwebtoken").sign({
			sub: user.id,
			email: user.email,
			phone: user.phone || "",
			display_name: user.display_name || ""
		}, JWT_SECRET, { expiresIn: "7d" }),
		token_type: "bearer",
		expires_in: 604800,
		refresh_token: "refresh_" + Math.random().toString(36).substring(7),
		user: {
			id: user.id,
			email: user.email,
			phone: user.phone || "",
			user_metadata: { display_name: user.display_name || "" }
		}
	};
}
async function verifyAuthToken(request) {
	const authHeader = request.headers.get("authorization");
	if (!authHeader?.startsWith("Bearer ")) return null;
	const token = authHeader.replace("Bearer ", "");
	try {
		return __require("jsonwebtoken").verify(token, JWT_SECRET);
	} catch {
		return null;
	}
}
function json(data, status = 200) {
	return new Response(JSON.stringify(data), {
		status,
		headers: { "Content-Type": "application/json" }
	});
}
//#endregion
export { auth_server_phwZTC7H_exports as n, __exportAll as t };
