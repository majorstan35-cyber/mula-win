import { a as __toESM } from "../_runtime.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { n as useServerFn, t as createSsrRpc } from "./createSsrRpc-BeJ9_ac2.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CvvfbxTP.mjs";
import { n as useAuth } from "./auth-context-c4SXRgOr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-D0viv2y2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var adminOverview = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("65dbdd42678d4cf3348f8143806993df600c6d6e2d11eded1594324413609a95"));
var setJackpotConfig = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((data) => data).handler(createSsrRpc("07442cc3338bcc24b52b328a7b046b9b15af29c57c0080c9ed92ce1caf217871"));
var setUserBlocked = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((data) => data).handler(createSsrRpc("3039656cce10640eb95b043ad0b5438606d4c6b5cb3a63bb61436a3d25752d1a"));
function AdminPage() {
	const { user, loading } = useAuth();
	const navigate = useNavigate();
	const fetchOverview = useServerFn(adminOverview);
	const saveConfig = useServerFn(setJackpotConfig);
	const toggleBlock = useServerFn(setUserBlocked);
	const [data, setData] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(null);
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!loading && !user) navigate({ to: "/auth" });
	}, [
		loading,
		user,
		navigate
	]);
	async function reload() {
		try {
			setData(await fetchOverview());
		} catch (e) {
			setErr(e.message);
		}
	}
	(0, import_react.useEffect)(() => {
		if (user) reload();
	}, [user]);
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "p-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-[color:var(--destructive)]",
			children: err
		})
	});
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "p-8 text-sm text-[color:var(--muted-foreground)]",
		children: "Loading…"
	});
	const m = data.metrics;
	const c = data.config;
	async function updateConfig(patch) {
		setSaving(true);
		try {
			await saveConfig({ data: patch });
			await reload();
		} catch (e) {
			setErr(e.message);
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-4xl px-5 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "text-sm text-[color:var(--muted-foreground)]",
					children: "← Back"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs uppercase tracking-widest text-[color:var(--gold-soft)]",
					children: "Admin"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-display text-3xl font-bold",
				children: "Mula Admin"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Revenue (KES)",
						value: m.totalRevenue.toLocaleString()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Payouts (KES)",
						value: m.totalPayouts.toLocaleString()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Net margin",
						value: m.netMargin.toLocaleString(),
						accent: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Runs",
						value: String(m.runCount)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 rounded-2xl border border-[color:var(--border)] bg-[color:var(--card)]/50 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-bold",
						children: "Jackpot config"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfigField, {
								label: "Jackpot KES",
								value: c.jackpot_amount_kes,
								onSave: (v) => updateConfig({ jackpot_amount_kes: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfigField, {
								label: "Ticket KES",
								value: c.ticket_price_kes,
								onSave: (v) => updateConfig({ ticket_price_kes: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfigField, {
								label: "Pool max",
								value: c.pool_max,
								onSave: (v) => updateConfig({ pool_max: v })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: saving,
							onClick: () => updateConfig({ paused: !c.paused }),
							className: `rounded-lg px-4 py-2 text-sm font-semibold ${c.paused ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`,
							children: c.paused ? "Resume draws" : "Pause draws"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-[color:var(--muted-foreground)]",
							children: ["Status: ", c.paused ? "PAUSED" : "LIVE"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-[color:var(--muted-foreground)]",
							children: "Prize tiers"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid grid-cols-2 gap-1 text-xs sm:grid-cols-4",
							children: c.prize_tiers.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-[color:var(--border)] px-2 py-1",
								children: [
									"Match ",
									t.match,
									" → ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[color:var(--gold-soft)]",
										children: ["KES ", t.prize_kes.toLocaleString()]
									})
								]
							}, t.match))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 rounded-2xl border border-[color:var(--border)] bg-[color:var(--card)]/50 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-bold",
					children: "Users"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-[color:var(--border)]",
					children: data.users.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: u.display_name ?? u.phone ?? u.id.slice(0, 8) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-[color:var(--muted-foreground)]",
							children: new Date(u.created_at).toLocaleDateString()
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => toggleBlock({ data: {
								userId: u.id,
								blocked: !u.blocked
							} }).then(reload),
							className: `rounded-md px-3 py-1 text-xs ${u.blocked ? "bg-red-500/20 text-red-400" : "bg-[color:var(--muted)]/40"}`,
							children: u.blocked ? "Blocked" : "Block"
						})]
					}, u.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 rounded-2xl border border-[color:var(--border)] bg-[color:var(--card)]/50 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-bold",
					children: "Recent runs"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-[color:var(--border)] text-sm",
					children: data.recentRuns.slice(0, 20).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: new Date(r.created_at).toLocaleString() }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono",
								children: [r.matched_count ?? 0, "/12"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: r.prize_kes ? "text-[color:var(--gold)]" : "text-[color:var(--muted-foreground)]",
								children: r.prize_kes ? `+${r.prize_kes.toLocaleString()}` : "—"
							})
						]
					}, r.id))
				})]
			})
		]
	});
}
function Metric({ label, value, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-[color:var(--border)] bg-[color:var(--card)]/50 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `mt-1 font-display text-2xl font-bold ${accent ? "text-[color:var(--gold)]" : ""}`,
			children: value
		})]
	});
}
function ConfigField({ label, value, onSave }) {
	const [v, setV] = (0, import_react.useState)(String(value));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: v,
				onChange: (e) => setV(e.target.value),
				className: "w-full rounded-md border border-[color:var(--border)] bg-[color:var(--input)] px-2 py-1 text-sm"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => onSave(Number(v)),
				className: "rounded-md bg-[color:var(--gold)]/20 px-2 text-xs font-semibold text-[color:var(--gold-soft)]",
				children: "Save"
			})]
		})]
	});
}
//#endregion
export { AdminPage as component };
