//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-DoteMfEW.js
var manifest = {
	"07442cc3338bcc24b52b328a7b046b9b15af29c57c0080c9ed92ce1caf217871": {
		functionName: "setJackpotConfig_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-3Za76tFG.mjs")
	},
	"2c5a1c3f656b2ce185d8efc1cf1ddc58e316d37ce9230bef0f7259644f6ea4e9": {
		functionName: "initiateMpesaCharge_createServerFn_handler",
		importer: () => import("./_ssr/paystack.functions-BrF-u7fZ.mjs")
	},
	"3039656cce10640eb95b043ad0b5438606d4c6b5cb3a63bb61436a3d25752d1a": {
		functionName: "setUserBlocked_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-3Za76tFG.mjs")
	},
	"65dbdd42678d4cf3348f8143806993df600c6d6e2d11eded1594324413609a95": {
		functionName: "adminOverview_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-3Za76tFG.mjs")
	},
	"7ae624642cc477a2eff4e939e62b5919094dc4161ca9497e61bb30547940fa17": {
		functionName: "getPublicState_createServerFn_handler",
		importer: () => import("./_ssr/draw.functions-DW2EjzNh.mjs")
	},
	"9be9deca1f6a16c3881518acd185fbd6f04dec433f6fde78a4cdf90c0639928a": {
		functionName: "getMyHistory_createServerFn_handler",
		importer: () => import("./_ssr/draw.functions-DW2EjzNh.mjs")
	},
	"b26d90fa23774e657989ba272e7498a807e3286d09b2230b9dda540c8124536f": {
		functionName: "getRunStatus_createServerFn_handler",
		importer: () => import("./_ssr/paystack.functions-BrF-u7fZ.mjs")
	},
	"d969e1aa43de13f09ea470e3cff80f1b652b13c5a154008e3a8bdb2c58366b47": {
		functionName: "playNow_createServerFn_handler",
		importer: () => import("./_ssr/draw.functions-DW2EjzNh.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
