import { f as getRequest, l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CvvfbxTP.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import process from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/paystack.functions-BrF-u7fZ.js
function backendBase() {
	if (process.env.BACKEND_API_URL) return process.env.BACKEND_API_URL;
	const req = getRequest();
	return (req?.url ? new URL(req.url).origin : `http://localhost:${process.env.PORT || 3e3}`) + "/api";
}
function getAuthHeaders() {
	const authHeader = getRequest()?.headers?.get("authorization");
	return authHeader ? {
		Authorization: authHeader,
		"Content-Type": "application/json"
	} : { "Content-Type": "application/json" };
}
var initiateMpesaCharge_createServerFn_handler = createServerRpc({
	id: "2c5a1c3f656b2ce185d8efc1cf1ddc58e316d37ce9230bef0f7259644f6ea4e9",
	name: "initiateMpesaCharge",
	filename: "src/lib/paystack.functions.ts"
}, (opts) => initiateMpesaCharge.__executeServer(opts));
var initiateMpesaCharge = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((data) => data).handler(initiateMpesaCharge_createServerFn_handler, async ({ data }) => {
	try {
		const res = await fetch(`${backendBase()}/payments/initiate-charge`, {
			method: "POST",
			headers: getAuthHeaders(),
			body: JSON.stringify(data)
		});
		if (!res.ok) {
			const err = await res.json();
			throw new Error(err.message || "Failed to initiate payment");
		}
		return await res.json();
	} catch (err) {
		console.error("initiateMpesaCharge forwarding error:", err.message);
		throw err;
	}
});
var getRunStatus_createServerFn_handler = createServerRpc({
	id: "b26d90fa23774e657989ba272e7498a807e3286d09b2230b9dda540c8124536f",
	name: "getRunStatus",
	filename: "src/lib/paystack.functions.ts"
}, (opts) => getRunStatus.__executeServer(opts));
var getRunStatus = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).validator((data) => data).handler(getRunStatus_createServerFn_handler, async ({ data }) => {
	try {
		const res = await fetch(`${backendBase()}/payments/run-status/${data.runId}`, {
			method: "GET",
			headers: getAuthHeaders()
		});
		if (!res.ok) {
			const err = await res.json();
			throw new Error(err.message || "Failed to check run status");
		}
		return await res.json();
	} catch (err) {
		console.error("getRunStatus forwarding error:", err.message);
		throw err;
	}
});
//#endregion
export { getRunStatus_createServerFn_handler, initiateMpesaCharge_createServerFn_handler };
