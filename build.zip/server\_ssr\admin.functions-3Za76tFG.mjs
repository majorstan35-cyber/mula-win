import { f as getRequest, l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CvvfbxTP.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import process from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-3Za76tFG.js
function backendBase() {
	if (process.env.BACKEND_API_URL) return process.env.BACKEND_API_URL;
	const req = getRequest();
	return (req?.url ? new URL(req.url).origin : `http://localhost:${process.env.PORT || 3e3}`) + "/api";
}
function getAuthHeaders() {
	const authHeader = getRequest()?.headers?.get("authorization");
	return authHeader ? {
		Authorization: authHeader,
		"Content-Type": "application/json"
	} : { "Content-Type": "application/json" };
}
var adminOverview_createServerFn_handler = createServerRpc({
	id: "65dbdd42678d4cf3348f8143806993df600c6d6e2d11eded1594324413609a95",
	name: "adminOverview",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminOverview.__executeServer(opts));
var adminOverview = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(adminOverview_createServerFn_handler, async () => {
	try {
		const res = await fetch(`${backendBase()}/admin/overview`, {
			method: "GET",
			headers: getAuthHeaders()
		});
		if (!res.ok) {
			const err = await res.json();
			throw new Error(err.message || "Failed to fetch admin overview");
		}
		return await res.json();
	} catch (err) {
		console.error("adminOverview forwarding error:", err.message);
		throw err;
	}
});
var setJackpotConfig_createServerFn_handler = createServerRpc({
	id: "07442cc3338bcc24b52b328a7b046b9b15af29c57c0080c9ed92ce1caf217871",
	name: "setJackpotConfig",
	filename: "src/lib/admin.functions.ts"
}, (opts) => setJackpotConfig.__executeServer(opts));
var setJackpotConfig = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((data) => data).handler(setJackpotConfig_createServerFn_handler, async ({ data }) => {
	try {
		const res = await fetch(`${backendBase()}/admin/config`, {
			method: "POST",
			headers: getAuthHeaders(),
			body: JSON.stringify(data)
		});
		if (!res.ok) {
			const err = await res.json();
			throw new Error(err.message || "Failed to update jackpot config");
		}
		return await res.json();
	} catch (err) {
		console.error("setJackpotConfig forwarding error:", err.message);
		throw err;
	}
});
var setUserBlocked_createServerFn_handler = createServerRpc({
	id: "3039656cce10640eb95b043ad0b5438606d4c6b5cb3a63bb61436a3d25752d1a",
	name: "setUserBlocked",
	filename: "src/lib/admin.functions.ts"
}, (opts) => setUserBlocked.__executeServer(opts));
var setUserBlocked = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((data) => data).handler(setUserBlocked_createServerFn_handler, async ({ data }) => {
	try {
		const res = await fetch(`${backendBase()}/admin/user-blocked`, {
			method: "POST",
			headers: getAuthHeaders(),
			body: JSON.stringify(data)
		});
		if (!res.ok) {
			const err = await res.json();
			throw new Error(err.message || "Failed to update user block status");
		}
		return await res.json();
	} catch (err) {
		console.error("setUserBlocked forwarding error:", err.message);
		throw err;
	}
});
//#endregion
export { adminOverview_createServerFn_handler, setJackpotConfig_createServerFn_handler, setUserBlocked_createServerFn_handler };
