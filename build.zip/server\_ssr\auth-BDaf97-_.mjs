import { a as __toESM } from "../_runtime.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { t as supabase } from "./client-BM5UVnrl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-BDaf97-_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthPage() {
	const navigate = useNavigate();
	const [mode, setMode] = (0, import_react.useState)("signup");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	async function submit(e) {
		e.preventDefault();
		setErr(null);
		setLoading(true);
		try {
			if (mode === "signup") {
				const { data, error } = await supabase.auth.signUp({
					email,
					password,
					phone: phone || void 0,
					options: { emailRedirectTo: window.location.origin }
				});
				if (error) throw error;
				if (data.user && phone) await supabase.from("profiles").update({ phone }).eq("id", data.user.id);
			} else {
				const { error } = await supabase.auth.signInWithPassword({
					email,
					password
				});
				if (error) throw error;
			}
			navigate({ to: "/" });
		} catch (e) {
			setErr(e.message ?? "Something went wrong");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "mb-8 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-gold-gradient shadow-gold-soft flex h-9 w-9 items-center justify-center rounded-full font-display text-lg font-black text-[oklch(0.14_0.01_60)]",
					children: "M"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xl font-bold tracking-tight",
					children: "Mula"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-bold",
				children: mode === "signup" ? "Create account" : "Welcome back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-[color:var(--muted-foreground)]",
				children: mode === "signup" ? "Play the KES 1,000,000 jackpot." : "Sign in to keep playing."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "mt-6 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "email",
						placeholder: "Email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						required: true,
						className: "w-full rounded-xl border border-[color:var(--border)] bg-[color:var(--input)] px-4 py-3 text-sm outline-none focus:border-[color:var(--gold)]"
					}),
					mode === "signup" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "tel",
						placeholder: "M-Pesa phone (e.g. 0712345678)",
						value: phone,
						onChange: (e) => setPhone(e.target.value),
						className: "w-full rounded-xl border border-[color:var(--border)] bg-[color:var(--input)] px-4 py-3 text-sm outline-none focus:border-[color:var(--gold)]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "password",
						placeholder: "Password",
						value: password,
						onChange: (e) => setPassword(e.target.value),
						required: true,
						className: "w-full rounded-xl border border-[color:var(--border)] bg-[color:var(--input)] px-4 py-3 text-sm outline-none focus:border-[color:var(--gold)]"
					}),
					err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-lg border border-[color:var(--destructive)]/40 bg-[color:var(--destructive)]/10 px-3 py-2 text-xs text-[color:var(--destructive)]",
						children: err
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: loading,
						className: "bg-gold-gradient shadow-gold w-full rounded-xl py-3.5 font-display text-lg font-bold text-[oklch(0.12_0.01_60)] disabled:opacity-60",
						children: loading ? "Please wait…" : mode === "signup" ? "Create account" : "Sign in"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setMode(mode === "signup" ? "signin" : "signup"),
				className: "mt-6 text-center text-xs text-[color:var(--muted-foreground)] underline",
				children: mode === "signup" ? "Already have an account? Sign in" : "New here? Create an account"
			})
		]
	});
}
//#endregion
export { AuthPage as component };
