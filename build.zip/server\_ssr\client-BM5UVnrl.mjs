import process from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/client-BM5UVnrl.js
var BACKEND_URL = typeof window !== "undefined" ? "/api" : typeof process !== "undefined" && process.env?.BACKEND_API_URL || `http://localhost:${process.env.PORT || 3e3}/api`;
function decodeJwt(token) {
	try {
		const base64 = token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
		const jsonPayload = decodeURIComponent(atob(base64).split("").map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2)).join(""));
		return JSON.parse(jsonPayload);
	} catch (e) {
		return null;
	}
}
var MockSupabaseAuth = class {
	listeners = [];
	constructor() {
		if (typeof window !== "undefined") {
			if (localStorage.getItem("spin_token")) this.getSession().then(({ data }) => {
				if (data?.session) this.trigger("SIGNED_IN", data.session);
			});
		}
	}
	async signUp({ email, password, options }) {
		try {
			const response = await fetch(`${BACKEND_URL}/auth/signup`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					email,
					password,
					phone: options?.data?.phone,
					displayName: options?.data?.display_name
				})
			});
			const data = await response.json();
			if (!response.ok) return {
				data: null,
				error: new Error(data.message || "Signup failed")
			};
			if (typeof window !== "undefined") localStorage.setItem("spin_token", data.session.access_token);
			this.trigger("SIGNED_IN", data.session);
			return {
				data: {
					user: data.user,
					session: data.session
				},
				error: null
			};
		} catch (err) {
			return {
				data: null,
				error: err
			};
		}
	}
	async signInWithPassword({ email, password }) {
		try {
			const response = await fetch(`${BACKEND_URL}/auth/signin`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					email,
					password
				})
			});
			const data = await response.json();
			if (!response.ok) return {
				data: null,
				error: new Error(data.message || "Signin failed")
			};
			if (typeof window !== "undefined") localStorage.setItem("spin_token", data.session.access_token);
			this.trigger("SIGNED_IN", data.session);
			return {
				data: {
					user: data.user,
					session: data.session
				},
				error: null
			};
		} catch (err) {
			return {
				data: null,
				error: err
			};
		}
	}
	async signOut() {
		if (typeof window !== "undefined") localStorage.removeItem("spin_token");
		this.trigger("SIGNED_OUT", null);
		return { error: null };
	}
	async getSession() {
		if (typeof window === "undefined") return {
			data: { session: null },
			error: null
		};
		const token = localStorage.getItem("spin_token");
		if (!token) return {
			data: { session: null },
			error: null
		};
		const decoded = decodeJwt(token);
		if (!decoded || decoded.exp && decoded.exp * 1e3 < Date.now()) {
			localStorage.removeItem("spin_token");
			return {
				data: { session: null },
				error: null
			};
		}
		return {
			data: { session: {
				access_token: token,
				user: {
					id: decoded.sub,
					email: decoded.email,
					phone: decoded.phone,
					user_metadata: { display_name: decoded.display_name }
				}
			} },
			error: null
		};
	}
	onAuthStateChange(callback) {
		this.listeners.push(callback);
		this.getSession().then(({ data }) => {
			if (data?.session) callback("SIGNED_IN", data.session);
		});
		return { data: { subscription: { unsubscribe: () => {
			this.listeners = this.listeners.filter((l) => l !== callback);
		} } } };
	}
	trigger(event, session) {
		this.listeners.forEach((l) => {
			try {
				l(event, session);
			} catch (err) {
				console.error("Auth state change callback error:", err);
			}
		});
	}
};
var QueryBuilder = class {
	table;
	filters = {};
	constructor(table) {
		this.table = table;
	}
	select(fields) {
		return this;
	}
	update(data) {
		this.filters.updateData = data;
		return this;
	}
	eq(field, value) {
		this.filters[field] = value;
		return this;
	}
	async maybeSingle() {
		return this.execute();
	}
	async single() {
		return this.execute();
	}
	async then(onfulfilled, onrejected) {
		return this.execute().then(onfulfilled, onrejected);
	}
	async execute() {
		const token = typeof window !== "undefined" ? localStorage.getItem("spin_token") : null;
		const headers = { "Content-Type": "application/json" };
		if (token) headers["Authorization"] = `Bearer ${token}`;
		try {
			if (this.table === "profiles") if (this.filters.updateData) {
				const response = await fetch(`${BACKEND_URL}/auth/profiles`, {
					method: "PUT",
					headers,
					body: JSON.stringify(this.filters.updateData)
				});
				const data = await response.json();
				if (!response.ok) return {
					data: null,
					error: new Error(data.message)
				};
				return {
					data,
					error: null
				};
			} else {
				const response = await fetch(`${BACKEND_URL}/auth/profiles/me`, {
					method: "GET",
					headers
				});
				const data = await response.json();
				if (!response.ok) return {
					data: null,
					error: new Error(data.message)
				};
				return {
					data,
					error: null
				};
			}
			return {
				data: null,
				error: /* @__PURE__ */ new Error("Unsupported local table query: " + this.table)
			};
		} catch (err) {
			return {
				data: null,
				error: err
			};
		}
	}
};
var supabase = {
	auth: new MockSupabaseAuth(),
	from(table) {
		return new QueryBuilder(table);
	}
};
//#endregion
export { supabase as t };
