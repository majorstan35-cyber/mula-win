import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-docs-CCIL9Zty.js
var import_jsx_runtime = require_jsx_runtime();
var GROUPS = [
	{
		title: "Game (public + user)",
		endpoints: [
			{
				method: "GET",
				path: "/_serverFn/getPublicState",
				auth: "public",
				desc: "Active jackpot config + current open round with seed_hash commit (provably-fair).",
				res: "{ config: JackpotConfig, round: { id, round_number, seed_hash, target_numbers[], status } }"
			},
			{
				method: "POST",
				path: "/_serverFn/playNow",
				auth: "user",
				desc: "Create a run for the current round, generate 12 player numbers deterministically from (server_seed | user_id | run_id), score against target, apply tiered prize.",
				req: "{ phone?: string }",
				res: "{ run, target[], seedHash, roundNumber }"
			},
			{
				method: "GET",
				path: "/_serverFn/getMyHistory",
				auth: "user",
				desc: "Last 50 runs for the current player (matched_count, prize_kes, drawn_at).",
				res: "Run[]"
			}
		]
	},
	{
		title: "Payments — Paystack",
		endpoints: [
			{
				method: "POST",
				path: "/_serverFn/paystackInitialize",
				auth: "user",
				desc: "Create pending run, call Paystack /transaction/initialize (KES 200 kobo), return authorization_url + reference.",
				req: "{ email: string }",
				res: "{ authorization_url, reference, run_id }"
			},
			{
				method: "POST",
				path: "/api/public/paystack/webhook",
				auth: "webhook",
				desc: "Paystack callback. Verify HMAC-SHA512 with PAYSTACK_SECRET_KEY, mark payment paid, trigger draw, finalise run.",
				req: "{ event: 'charge.success', data: { reference, amount, ... } }",
				res: "200 ok"
			},
			{
				method: "GET",
				path: "/_serverFn/verifyPayment",
				auth: "user",
				desc: "Poll a run by reference after redirect from Paystack; returns finalised run when webhook has completed.",
				req: "{ reference: string }",
				res: "{ status, run? }"
			}
		]
	},
	{
		title: "Payments — Flutterwave",
		endpoints: [{
			method: "POST",
			path: "/_serverFn/flutterwaveInitialize",
			auth: "user",
			desc: "Create pending run, call Flutterwave /payments (KES 200), return payment link + tx_ref.",
			req: "{ email: string, phone?: string }",
			res: "{ link, tx_ref, run_id }"
		}, {
			method: "POST",
			path: "/api/public/flutterwave/webhook",
			auth: "webhook",
			desc: "Flutterwave callback. Verify verif-hash header against FLW_SECRET_HASH, verify transaction via GET /transactions/:id/verify, mark paid, run draw.",
			res: "200 ok"
		}]
	},
	{
		title: "Auth",
		endpoints: [
			{
				method: "POST",
				path: "supabase.auth.signUp",
				auth: "public",
				desc: "Email + password sign-up (phone stored in profiles)."
			},
			{
				method: "POST",
				path: "supabase.auth.signInWithPassword",
				auth: "public",
				desc: "Sign in."
			},
			{
				method: "POST",
				path: "supabase.auth.signOut",
				auth: "user",
				desc: "Sign out."
			}
		]
	},
	{
		title: "Admin",
		endpoints: [
			{
				method: "GET",
				path: "/_serverFn/adminOverview",
				auth: "admin",
				desc: "Revenue, payouts, net margin, run count, win rate, recent runs, users, config.",
				res: "{ metrics, recentRuns[], users[], config }"
			},
			{
				method: "POST",
				path: "/_serverFn/setJackpotConfig",
				auth: "admin",
				desc: "Update jackpot amount, ticket price, pool range, prize tiers, or pause/resume draws.",
				req: "{ jackpot_amount_kes?, ticket_price_kes?, pool_min?, pool_max?, numbers_per_draw?, paused?, prize_tiers? }"
			},
			{
				method: "POST",
				path: "/_serverFn/setUserBlocked",
				auth: "admin",
				desc: "Block or unblock a player.",
				req: "{ userId: string, blocked: boolean }"
			}
		]
	}
];
function ApiDocsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "text-sm text-[color:var(--muted-foreground)]",
				children: "← Back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-display text-4xl font-black",
				children: "API reference"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-[color:var(--muted-foreground)]",
				children: "Backend surface for Mula — server functions (RPC over HTTPS) + public webhooks. RLS enforced via Supabase."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 space-y-8",
				children: GROUPS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-bold text-[color:var(--gold-soft)]",
					children: g.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-3",
					children: g.endpoints.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl border border-[color:var(--border)] bg-[color:var(--card)]/60 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded-md px-2 py-0.5 font-mono text-[10px] font-bold ${e.method === "GET" ? "bg-emerald-500/15 text-emerald-400" : "bg-sky-500/15 text-sky-400"}`,
										children: e.method
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
										className: "font-mono text-sm text-[color:var(--foreground)]",
										children: e.path
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `ml-auto rounded-full px-2 py-0.5 text-[10px] uppercase tracking-wider ${e.auth === "public" ? "bg-[color:var(--muted)]/40 text-[color:var(--muted-foreground)]" : e.auth === "user" ? "bg-[color:var(--gold)]/15 text-[color:var(--gold-soft)]" : e.auth === "admin" ? "bg-red-500/15 text-red-400" : "bg-purple-500/15 text-purple-300"}`,
										children: e.auth
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-[color:var(--foreground)]/85",
								children: e.desc
							}),
							e.req && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 font-mono text-[11px] text-[color:var(--muted-foreground)]",
								children: ["req: ", e.req]
							}),
							e.res && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-mono text-[11px] text-[color:var(--muted-foreground)]",
								children: ["res: ", e.res]
							})
						]
					}, e.path + e.method))
				})] }, g.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-12 border-t border-[color:var(--border)] pt-6 text-xs text-[color:var(--muted-foreground)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"Secrets needed for live payments: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "PAYSTACK_SECRET_KEY" }),
					", ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "FLW_SECRET_KEY" }),
					", ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "FLW_SECRET_HASH" }),
					"."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1",
					children: "All state-changing endpoints use Zod validation and Supabase RLS. Webhooks verify provider signatures before touching the DB."
				})]
			})
		]
	});
}
//#endregion
export { ApiDocsPage as component };
