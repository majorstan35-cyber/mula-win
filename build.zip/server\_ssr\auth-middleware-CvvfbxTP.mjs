import { a as __toESM } from "../_runtime.mjs";
import { t as createMiddleware } from "./createStart-Dt05N14y.mjs";
import { f as getRequest } from "./esm-9EjmF9OT.mjs";
import { t as supabase } from "./client-BM5UVnrl.mjs";
import process from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-middleware-CvvfbxTP.js
var JWT_SECRET = process.env.JWT_SECRET || "super_secret_lucky_spin_jwt_key";
var requireSupabaseAuth = createMiddleware({ type: "function" }).server(async ({ next }) => {
	const request = getRequest();
	if (!request?.headers) throw new Error("Unauthorized: No request headers available");
	const authHeader = request.headers.get("authorization");
	if (!authHeader) throw new Error("Unauthorized: No authorization header provided");
	if (!authHeader.startsWith("Bearer ")) throw new Error("Unauthorized: Only Bearer tokens are supported");
	const token = authHeader.replace("Bearer ", "");
	if (!token) throw new Error("Unauthorized: No token provided");
	try {
		const jwtModule = await import("../_libs/jsonwebtoken+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
		const decoded = (jwtModule.default || jwtModule).verify(token, JWT_SECRET);
		if (!decoded || !decoded.sub) throw new Error("Unauthorized: Invalid token structure");
		return next({ context: {
			supabase,
			userId: decoded.sub,
			claims: decoded
		} });
	} catch (err) {
		console.error("Local token verification failed on serverFn middleware:", err.message);
		throw new Error("Unauthorized: Invalid or expired token");
	}
});
//#endregion
export { requireSupabaseAuth as t };
