import { f as getRequest, l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CvvfbxTP.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import process from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/draw.functions-DW2EjzNh.js
function backendBase() {
	if (process.env.BACKEND_API_URL) return process.env.BACKEND_API_URL;
	const req = getRequest();
	return (req?.url ? new URL(req.url).origin : `http://localhost:${process.env.PORT || 3e3}`) + "/api";
}
function getAuthHeaders() {
	const authHeader = getRequest()?.headers?.get("authorization");
	return authHeader ? {
		Authorization: authHeader,
		"Content-Type": "application/json"
	} : { "Content-Type": "application/json" };
}
var getPublicState_createServerFn_handler = createServerRpc({
	id: "7ae624642cc477a2eff4e939e62b5919094dc4161ca9497e61bb30547940fa17",
	name: "getPublicState",
	filename: "src/lib/draw.functions.ts"
}, (opts) => getPublicState.__executeServer(opts));
var getPublicState = createServerFn({ method: "GET" }).handler(getPublicState_createServerFn_handler, async () => {
	try {
		const res = await fetch(`${backendBase()}/game/public-state`);
		if (!res.ok) {
			const err = await res.json();
			throw new Error(err.message || "Failed to fetch public state");
		}
		return await res.json();
	} catch (err) {
		console.error("getPublicState forwarding error:", err.message);
		throw err;
	}
});
var playNow_createServerFn_handler = createServerRpc({
	id: "d969e1aa43de13f09ea470e3cff80f1b652b13c5a154008e3a8bdb2c58366b47",
	name: "playNow",
	filename: "src/lib/draw.functions.ts"
}, (opts) => playNow.__executeServer(opts));
var playNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((data) => data ?? {}).handler(playNow_createServerFn_handler, async ({ data }) => {
	try {
		const res = await fetch(`${backendBase()}/game/play`, {
			method: "POST",
			headers: getAuthHeaders(),
			body: JSON.stringify(data)
		});
		if (!res.ok) {
			const err = await res.json();
			throw new Error(err.message || "Play failed");
		}
		return await res.json();
	} catch (err) {
		console.error("playNow forwarding error:", err.message);
		throw err;
	}
});
var getMyHistory_createServerFn_handler = createServerRpc({
	id: "9be9deca1f6a16c3881518acd185fbd6f04dec433f6fde78a4cdf90c0639928a",
	name: "getMyHistory",
	filename: "src/lib/draw.functions.ts"
}, (opts) => getMyHistory.__executeServer(opts));
var getMyHistory = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getMyHistory_createServerFn_handler, async () => {
	try {
		const res = await fetch(`${backendBase()}/game/history`, {
			method: "GET",
			headers: getAuthHeaders()
		});
		if (!res.ok) {
			const err = await res.json();
			throw new Error(err.message || "Failed to fetch history");
		}
		return await res.json();
	} catch (err) {
		console.error("getMyHistory forwarding error:", err.message);
		throw err;
	}
});
//#endregion
export { getMyHistory_createServerFn_handler, getPublicState_createServerFn_handler, playNow_createServerFn_handler };
