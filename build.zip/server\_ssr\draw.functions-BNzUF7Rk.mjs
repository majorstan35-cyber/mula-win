import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as createSsrRpc } from "./createSsrRpc-BeJ9_ac2.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CvvfbxTP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/draw.functions-BNzUF7Rk.js
var getPublicState = createServerFn({ method: "GET" }).handler(createSsrRpc("7ae624642cc477a2eff4e939e62b5919094dc4161ca9497e61bb30547940fa17"));
createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((data) => data ?? {}).handler(createSsrRpc("d969e1aa43de13f09ea470e3cff80f1b652b13c5a154008e3a8bdb2c58366b47"));
var getMyHistory = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("9be9deca1f6a16c3881518acd185fbd6f04dec433f6fde78a4cdf90c0639928a"));
//#endregion
export { getPublicState as n, getMyHistory as t };
